import React from "react";
import styles from "./Footer.module.scss";
import { Icons } from "../../utilities/icons.js";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={styles.footer}>
      <img
        className={styles.dividerTop}
        src="/images/divider-top.png"
        alt="section divider"
      />
      <div className={styles.container}>
        <div className={styles.content}>
          <div className={styles.section}>
            <h4>Contact</h4>
            <ul className={styles.contactList}>
              <li className={styles.listItem}>
                <Icons.location className={styles.techIcon} />
                <span className={styles.contactText}>
                  <a
                    href="https://www.google.dk/maps/place/4000+Roskilde/@55.6700326,11.9161574,32811m/data=!3m2!1e3!4b1!4m6!3m5!1s0x46525fc995012f29:0xa00afcc1d507710!8m2!3d55.64191!4d12.087845!16zL20vMGtzcHc?hl=da&entry=ttu&g_ep=EgoyMDI1MDYwMS4wIKXMDSoASAFQAw%3D%3D"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Roskilde, Denmark
                  </a>
                </span>
              </li>
              <li className={styles.listItem}>
                <Icons.phone className={styles.techIcon} />
                <span className={styles.contactText}>
                  <a href="tel:+4591953139">(+45) 91 95 31 39</a>
                </span>
              </li>
              <li className={styles.listItem}>
                <Icons.email className={styles.techIcon} />
                <span className={styles.contactText}>
                  <a href="mailto:marksgalkins@gmail.com">
                    marksgalkins@gmail.com
                  </a>
                </span>
              </li>
            </ul>
          </div>

          <div className={styles.section}>
            <h4>Navigation</h4>
            <ul className={styles.links}>
              <li>
                <a href="#hero">Home</a>
              </li>
              <li>
                <a href="#about">About</a>
              </li>
              <li>
                <a href="#projects">Projects</a>
              </li>
              <li>
                <a href="#contact">Contact</a>
              </li>
            </ul>
          </div>

          <div className={styles.section}>
            <h4>Connect</h4>
            <ul className={styles.socialLinks}>
              <li className="github">
                <a
                  href="https://github.com/GR0UD"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="GitHub"
                >
                  <Icons.github />
                </a>
              </li>
              <li className="linkedin">
                <a
                  href="https://www.linkedin.com/in/mark-galkins-7252092b0/"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="LinkedIn"
                >
                  <Icons.linkedin />
                </a>
              </li>
              <li className="codepen">
                <a
                  href="https://codepen.io/GROUD-the-solid"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="CodePen"
                >
                  <Icons.codepen />
                </a>
              </li>
              <li className="instagram">
                <a
                  href="https://www.instagram.com/gr0ud/"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Instagram"
                >
                  <Icons.instagram />
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className={styles.divider}></div>

        <div className={styles.bottom}>
          <p>&copy; {currentYear} Mark Galkins. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

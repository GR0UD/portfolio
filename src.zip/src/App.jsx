import { useRoutes } from "react-router-dom";
import routes from "~react-pages";
import BackupScroll from "./components/backup/backup.jsx";

function App() {
  const element = useRoutes(routes);
  return (
    <>
      {element}
      <BackupScroll />
    </>
  );
}

export default App;
